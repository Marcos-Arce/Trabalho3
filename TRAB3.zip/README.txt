		TRABALHO 3 DE ICC
	Alunos: Marcos Antonio Victor Arce - 10684621 - p=0
		Higor Tessari		   - 10345251 - p=1
	
	Esse programa visa a implementação de uma matriz esparsa na linguagem de programação C. Nele, manipula-se a matriz, podendo criar uma e removê-la, atribuir um valor a uma célula específica, alterar esse mesmo valor, calcular a soma dos valores de uma determinada linha ou coluna, consultar o valor de uma única célula, e/ou imprimir os valores de todas as células diferentes de 0.
	O programa foi feito tanto em Windows quanto em Linux, e há um arquivo para ser usado em cada.
